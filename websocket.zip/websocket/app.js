import express from 'express';
import multer from 'multer';
import fs from 'fs';
import { getUsers, getUser, addUser, auth ,updateUser,
        getUserPoll,getAllPoll,addPoll,getPollById,deletePoll,
        getPollByIdWithChoices,getPollWithChoices,getUserPollWithChoices,
        getChoice,deleteChoice,editChoice,addChoice,
        vote,addMenu,getMenu,updateMenu} from './database.js';
import { Server } from 'socket.io';
import { createServer } from 'http';
import path from 'path'
import { dirname } from 'path';
import { fileURLToPath } from 'url';


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const publicPath = path.join(__dirname, '/public')
const app = express();
const server = createServer(app);
const io = new Server(server);
app.use(express.static(publicPath))

app.use(express.json());

const storage = multer.memoryStorage(); // Store files in memory
const upload = multer({ storage: storage })


app.post('/uploadImage', upload.single('image'), (req, res) => {
  try {
    // Process the uploaded image (in-memory buffer in this example)
    const imageData = req.file.buffer;

    // Save the image to the "public" directory with a unique filename
    const filename = `image_${Date.now()}.jpg`;
    const filePath = path.join(publicPath, `/uploadImage/${filename}`);
    fs.writeFileSync(filePath, imageData);
    const imageUrl = `/uploadImage/${filename}`;
    res.json({ success: true, imageUrl });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});




//users
app.post("/auth", async (req, res) => {
    const { username, password } = req.body;
    try {
      const users = await auth(username,password);
      res.send(users);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  app.post("/addmenu", async (req, res) => {
    const { name,description,price,imageURL,calories,protein,carbs } = req.body;
    try {
      const menu = await addMenu(name,description,price,imageURL,calories,protein,carbs);
      res.send(menu);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  
  app.get("/getmenu", async (req, res) => {
    try {
        const menu = await getMenu();
        const baseURL = "http://localhost:8080";
        menu.forEach(item => {
            item.imageURL = baseURL + item.imageURL;
        });
        res.json({ "request": menu });
    } catch (error) {
        console.error(error);
        res.status(500).send('Something went wrong');
    }
});



app.post("/updatemenu", async (req, res) => {
  const {name,description,price,imageURL,calories,protein,carbs,id } = req.body;
  try {
    const menu = await updateMenu(name,description,price,imageURL,calories,protein,carbs,id);
    res.send(menu);
  } catch (error) {
    console.error(error);
    res.status(500).send('Something went wrong');
  }
});


app.post("/updateuser", async (req, res) => {
    const { name, email,id } = req.body;
    try {
      const users = await updateUser(name,email,id);
      res.send(users);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });  




app.get("/users", async (req, res) => {
    try {
      const users = await getUsers();
      res.send(users);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
app.get("/users", async (req, res) => {
  try {
    const users = await getUsers();
    res.send(users);
  } catch (error) {
    console.error(error);
    res.status(500).send('Something went wrong');
  }
});
app.get("/users/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const user = await getUser(id);
    res.send(user);
  } catch (error) {
    console.error(error);
    res.status(500).send('Something went wrong');
  }
});
app.post("/users", async (req, res) => {
  const { email,username, password, name } = req.body;
  try {
    const newUser = await addUser(email,username, password, name);
    res.send(newUser);
  } catch (error) {
    console.error(error);
    res.status(500).send('Something went wrong');
  }
});



//Poll
app.post("/userpoll", async (req, res) => {
    const { userid,} = req.body;
    try {
      const poll = await getUserPoll(userid);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  app.post("/addpoll", async (req, res) => {
    const { title,userId} = req.body;
    try {
      const poll = await addPoll(title,userId);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  app.post("/pollbyid", async (req, res) => {
    const { pollId} = req.body;
    try {
      const poll = await getPollById(pollId);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  app.get("/allpoll", async (req, res) => {
    try {
      const users = await getAllPoll();
      res.send(users);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  app.post("/pollbyidwithchoice", async (req, res) => {
    const {pollId} = req.body;
    try {
      const poll = await getPollByIdWithChoices(pollId);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  app.post("/deletepoll", async (req, res) => {
    const {pollId} = req.body;
    try {
      const poll = await deletePoll(pollId);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  
  app.get("/getpollwithchoices", async (req, res) => {
    try {
      const poll = await getPollWithChoices();
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  app.get("/getuserpollwithchoices/:id", async (req, res) => {
    const {id} = req.params;
    try {
      const poll = await getUserPollWithChoices(id);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  

  app.get("/getchoice/:pollId", async (req, res) => {
    const { pollId} = req.params;
    try {
      const poll = await getChoice(pollId);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });


  app.post("/editchoice", async (req, res) => {
    const { id,name} = req.body;
    try {
      const poll = await editChoice(id,name);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  app.post("/addchoice", async (req, res) => {
    const { id,name} = req.body;
    try {
      const poll = await addChoice(id,name);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  
  app.get("/deletechoice/:id", async (req, res) => {
    const { id} = req.params;
    try {
      const poll = await deleteChoice(id);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });
  
  
  app.post("/vote", async (req, res) => {
    const { pollId,	choiceId,userId} = req.body;
    try {
      const poll = await vote(pollId,choiceId,userId);
      res.send(poll);
    } catch (error) {
      console.error(error);
      res.status(500).send('Something went wrong');
    }
  });

  


// Start the server
const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

io.on('connection', (socket) => {
    console.log('A user connected');
    socket.on('getData', async () => {
      try {
          // Query the data you need from your database or other sources
          const queriedData = await getPollWithChoices(); 
          // Emit the queried data back to the client using the "dataResponse" event
          socket.emit('dataResponse', queriedData);
          console.log("asdasd")
          console.log(queriedData)
      } catch (error) {
          console.error(error);
          // Handle errors and possibly send an error response to the client
      }
  });
      socket.on('clientMessage', function(data) {
        console.log(data);
        io.sockets.emit('Message From Web',{msg: data,wew: data});
      });
      socket.on('chatMessage', function(data) {
        console.log(data);
        io.sockets.emit('IOS Server Connect',{msg: data});
      });
      
    socket.on('disconnect', () => {
      console.log('A user disconnected');
    });
  });

