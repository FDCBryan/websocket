import mysql from 'mysql2'
import dotenv from 'dotenv'
dotenv.config()
const pool = mysql.createPool({
    host: process.env.MYSQL_HOST ,
    user:process.env.MYSQL_USER ,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DB 
}).promise()




export async function getUsers(){
    const [rows] = await pool.query("Select * from users1 limit 10")
    return rows
}

export async function getUser(id){
    const [rows] = await pool.query(`Select * from
    users1 where id = ?`,[id])  
    return rows[0]
}

export async function auth(username, password) {
    const [rows] = await pool.query(
        `SELECT * FROM users1 WHERE username = ? AND password = ?`,
        [username, password]
    );

    if (rows.length === 0) {
        return {
            success: false,
            message: "Invalid Login"
        };
    }

    // Rows are not empty, return the first row
    return {
        success: true,
        user: rows[0]
    };
}

export async function updateUser(name, email,id) {
    const [rows] = await pool.query(
        `update users1 set name = ? , email = ? WHERE id = ?`,
        [name, email,id]
    );
    return getUser(id)

}


export async function addUser(email,username,password,name){
    const [checkuser] = await pool.query(`
    select * from users1 where email =  ? or username = ?`,[email,username])
    let count = checkuser.length; 
    if (count > 0) {
        return null
    } else{ 
        const [result] = await pool.query(`
        Insert into users1 (email,username,password,name)
        values (?,?,?,?)
        `,[email,username,password,name])
        return getUser(result.insertId)
    }    

}

export async function updateMenu(name,description,price,imageURL,calories,protein,carbs,id){
    const [checkuser] = await pool.query(`
    update  Appetizer set  name = ? ,description = ? ,price = ?,imageURL = ?,calories = ?,protein = ?,carbs = ? where id = ?`,[name,description,price,imageURL,calories,protein,carbs,id])
    return `ID ${id}` ; 
}
export async function addMenu(name,description,price,imageURL,calories,protein,carbs){
    const [checkuser] = await pool.query(`
    Insert into Appetizer (name,description,price,imageURL,calories,protein,carbs) values (?,?,?,?,?,?,?)`,[name,description,price,imageURL,calories,protein,carbs])
    return checkuser.insertId; 
}
// fucntions for getting Menu
export async function getMenu(){
    const [rows] = await pool.query(`Select * from
    Appetizer`)  
    return rows
}

// fucntions for getting Poll
export async function getUserPoll(userid){
    const [rows] = await pool.query(`Select * from
    polls where userId = ?`,[userid])  
    return rows
}

export async function deletePoll(id){
    const [rows] = await pool.query(`delete  from
    polls where id = ?`,[id])  
    const [rows1] = await pool.query(`delete  from
    choices where pollId = ?`,[id])  
    return {id:parseInt(id)}
}
export async function getPollById(id){
    const [rows] = await pool.query(`Select * from
    polls where id = ?`,[id])  
    return rows[0]
}
export async function getAllPoll(){
    const [rows] = await pool.query(`Select * from
    polls`)  
    return rows[0]
}

export async function addPoll(title,userId){
    const status = 1
    const [result] = await pool.query(`
    Insert into polls (title,userId,status)
    values (?,?,?)
    `,[title,userId,status])
    return getPollById(result.insertId)
}

export async function getPollByIdWithChoices(id){
    const [rows] = await pool.query(`SELECT
    users1.name,
    polls.id,
    polls.userId,
    polls.date,
    polls.title,
    COUNT(choices.id) AS count,
    CASE
        WHEN COUNT(choices.id) = 0 THEN NULL
        ELSE JSON_ARRAYAGG(
            JSON_OBJECT(
                'id', choices.id,
                'name', choices.name,
                'pollId', choices.pollId
            )
        )
    END AS choices
FROM
    polls
LEFT JOIN
    choices ON polls.id = choices.pollId
    LEFT JOIN
    users1 ON polls.userId = users1.Id
    where polls.id = ?
GROUP BY
    polls.id, polls.title order by polls.date desc`,[id]) 
    
    return rows
} 


export async function getPollWithChoices(){
    const [rows] = await pool.query(`SELECT
    users1.name,
    polls.id,
    polls.userId,
    polls.date,
    polls.title,
    COUNT(choices.id) AS count,
    CASE
        WHEN COUNT(choices.id) = 0 THEN NULL
        ELSE JSON_ARRAYAGG(
            JSON_OBJECT(
                'id', choices.id,
                'name', choices.name,
                'pollId', choices.pollId
            )
        )
    END AS choices
FROM
    polls
LEFT JOIN
    choices ON polls.id = choices.pollId
    LEFT JOIN
    users1 ON polls.userId = users1.Id
GROUP BY
    polls.id, polls.title order by polls.date desc;

`) 
    
    return rows
} 

export async function getUserPollWithChoices(id){
    const [rows] = await pool.query(`SELECT
    users1.name,
    polls.id,
    polls.userId,
    polls.date,
    polls.title,
    COUNT(choices.id) AS count,
    CASE
        WHEN COUNT(choices.id) = 0 THEN NULL
        ELSE JSON_ARRAYAGG(
            JSON_OBJECT(
                'id', choices.id,
                'name', choices.name,
                'pollId', choices.pollId
            )
        )
    END AS choices
FROM
    polls
LEFT JOIN
    choices ON polls.id = choices.pollId
    LEFT JOIN
    users1 ON polls.userId = users1.Id
    where polls.userId = ?
GROUP BY
    polls.id, polls.title order by polls.date desc;

`,[id]) 

    return rows
} 

//choices

export async function getChoice(id){
    const [rows] = await pool.query(`Select * ,
    (Select count(id)  from  votes where choiceId = choices.id) as voteCount
    from
    choices where pollId = ?`,[id])  
    return rows
}

export async function deleteChoice(id){
    const [rows] = await pool.query(`delete  from
    choices where id = ?`,[id])  
    return {id:parseInt(id) ,pollId:1,name:"asdasd",voteCount:0}
}
export async function editChoice(id,name){
    const [rows] = await pool.query(`update 
    choices set name = ? where id = ?`,[name,id])  
    return {id:id,name:name }
}

export async function addChoice(id,name){
    const [rows] = await pool.query(`Insert into choices (pollId,name)
    values (?,?)`,[id,name])  
    return {id:id,name:name }
}


export async function vote(	pollId,	choiceId,userId){
    const [checkvote] = await pool.query(`Select * from
    votes where pollId = ? and userId = ?`,[pollId,userId])  

    let count = checkvote.length; 
    if (count > 0) {
        const [rows] = await pool.query(`update votes set choiceId = ? where pollId = ? and userId = ? `,[choiceId,pollId,userId])  
    } else{ 
        const [rows] = await pool.query(`Insert into votes (pollId,	choiceId,userId)
        values (?,?,?)`,[pollId,choiceId,userId])  
    }
    const [checkvote1] = await pool.query(`Select * from votes where pollId = ? and userId = ?`,[pollId,userId])  
    return checkvote1
}